<section id="mesma-plataforma">
    <div class="container text-center">
        <div class="row equal ">
            <div class="col-xs-12 col-sm-10 col-sm-offset-1">
                <?php echo get_field('na_mesma_plataforma_paragrafo')?>
            </div>
        </div>
    </div>
</section><!-- mesma-plataforma -->
