
<div class="from">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-12 col-sm-6">
                <ul class="list-inline">
                    <li>
                        <a href="">
                            <img src="<?php echo plugins_url('../img/Apple@2x.png', __FILE__) ?>" alt="" class="img-responsive">
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <img src="<?php echo plugins_url('../img/GooglePlay@2x.png', __FILE__) ?>" alt="" class="img-responsive">
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-xs-12 col-sm-6">
                <p >
                    De
                    <a href="">
                        Belzonte
                    </a>
                    <?php _traduzir('to the world', 'para o Mundo')?>
                    
                    <img src="<?php echo plugins_url('../img/Brasil-BH@2x.png', __FILE__) ?>" alt=""> Made in Brasil
                </p>
            </div>
        </div>
    </div>
</div>
<!-- from -->