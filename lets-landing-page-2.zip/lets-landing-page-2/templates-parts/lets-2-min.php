<section id="lets-2-min">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <a class="btn btn-cinza" href="" data-toggle="modal" data-target="#myModal">
                    <i class="fas fa-chevron-circle-right"></i>
                    <?php _traduzir('LETS IN 2 MINUTES', 'LETS EM 2 MINUTOS');?>
                </a>
            </div>
        </div>
    </div>
</section>