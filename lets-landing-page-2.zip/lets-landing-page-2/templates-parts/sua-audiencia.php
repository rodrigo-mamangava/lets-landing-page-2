<section id="sua-audiencia" class="lazy" data-src="<?php echo get_field('sua_audiencia_imagem') ?>">

    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h1>
                    <?php echo get_field('sua_audiencia_titulo') ?>
                </h1>
                <p>
                    <?php echo get_field('sua_audiencia_descricao') ?>
                </p>
            </div>
        </div>
    </div>

</section><!-- sua-audiencia -->
