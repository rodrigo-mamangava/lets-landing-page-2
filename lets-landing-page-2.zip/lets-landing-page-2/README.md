# lets-landing-page-2
Plugin WP com landing page para Lets - v 2

#Processo de instalação:
1. Instalar os plugin que estão na pasta "install"
2. Ativar todos os plugin
3. Instalar o plugin "lets-landing-page-2"
4. Ativar o plugin "lets-landing-page-2"
5. Importar o arquvivo "campos_depoimentos_landingpage_02.xml" (que está na pasta "install") para o Wordpress.
6. Criar uma nova página e definir seu modelo para "Landing page - 2.0"

