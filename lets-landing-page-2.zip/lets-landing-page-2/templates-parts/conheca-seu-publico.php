<section id="conheca-seu-publico" data-bg="<?php echo get_field('conheca_seu_publico_imagem') ?>">
    <div class="container text-center">
        <div class="row">
            <div class="col-sm-12">
                <h1>
                    <?php echo get_field('conheça_seu_publico_titulo') ?>
                </h1>
            </div>
            <div class="col-sm-6 col-sm-offset-3">
                <?php echo get_field('conheca_seu_publico_descricao') ?>
            </div>
        </div>
    </div>
</section><!-- conheca-seu-publico -->
