<section id="formidaveis" class="animacao">
    <div class="container">
        <div class="row">

            <div class="col-xs-12 visible-xs visible-sm">
                <img src="img/ingresso-lista@2x.png" alt="" class="img-responsive">
            </div>

            <div class="col-md-4 col-md-offset-7">
                <h2>
                    <?php echo get_field('formidaveis_em_conjunto_titulo') ?>
                </h2>
            </div>
        </div>
    </div>
</section><!-- formidaveis -->
