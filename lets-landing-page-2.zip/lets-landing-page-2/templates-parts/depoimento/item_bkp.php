<div id="carousel-depoimentos" class="carousel slide" data-ride="carousel">



    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">

        <div class="item active">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="card-depoimento">
                        <div class="row">
                            <div class="col-sm-4">
                                <img src="img/img-depoimento@2x.png" alt="Túlio Borges, DDuck" class="img-responsive img-circle">

                                <h2>Túlio Borges, DDuck</h2>
                            </div>
                            <div class="col-sm-8">
                                <h3>Menos tempo gasto com listas</h3>
                                <p>
                                    O Lets além de ser uma ferramenta muito simples de usar, nos ajudou a poupar tempo e trabalho. Agora nossas listas de convidados
                                    ficam muito mais organizadas e os nossos clientes têm mais autonomia,
                                    podendo incluir novos nomes sem a necessidade de entrar em contato
                                    conosco.
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="item">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="card-depoimento">
                        <div class="row">
                            <div class="col-sm-4">
                                <img src="img/img-depoimento@2x.png" alt="Túlio Borges, DDuck" class="img-responsive">

                                <h2>Túlio Borges, DDuck</h2>
                            </div>
                            <div class="col-sm-8">
                                <h3>Menos tempo gasto com listas</h3>
                                <p>
                                    O Lets além de ser uma ferramenta muito simples de usar, nos ajudou a poupar tempo e trabalho. Agora nossas listas de convidados
                                    ficam muito mais organizadas e os nossos clientes têm mais autonomia,
                                    podendo incluir novos nomes sem a necessidade de entrar em contato
                                    conosco.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="item ">
            <div class="row">
                <div class="col-sm-10 col-sm-offset-1">
                    <div class="card-depoimento">
                        <div class="row">
                            <div class="col-sm-4">
                                <img src="img/img-depoimento@2x.png" alt="Túlio Borges, DDuck" class="img-responsive">

                                <h2>Túlio Borges, DDuck</h2>
                            </div>
                            <div class="col-sm-8">
                                <h3>Menos tempo gasto com listas</h3>
                                <p>
                                    O Lets além de ser uma ferramenta muito simples de usar, nos ajudou a poupar tempo e trabalho. Agora nossas listas de convidados
                                    ficam muito mais organizadas e os nossos clientes têm mais autonomia,
                                    podendo incluir novos nomes sem a necessidade de entrar em contato
                                    conosco.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</div>
