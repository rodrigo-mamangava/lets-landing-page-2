<section id="lets-2-min" class='hidden'>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <a class="btn btn-cinza" href="" data-toggle="modal" data-target="#myModal">
                    <span>▶</span>
                    <?php _traduzir('LETS IN 2 MINUTES', 'LETS EM 2 MINUTOS');?>
                </a>
            </div>
        </div>
    </div>
</section>