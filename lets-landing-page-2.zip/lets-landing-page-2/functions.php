<?php

function _traduzir($en, $pt){
    _e("[:en]{$en} [:pb]{$pt}");
}